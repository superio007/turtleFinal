﻿payment.php
Php file implement the Simple Client Post.

paymentDataFeed.php
Interface offer data feed to Paydollar system. The page is used in Paydollar transfer transaction information to merchant when agent finish credit card payment.

SHAPaydollarSecure.php,PaydollarSecure.php
php lib source for merchant when secureHash is used.


