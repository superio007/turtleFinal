<?php
header('Content-Type: application/json');
session_start();
include 'api_helper.php';  // Assuming your product fetching logic is here

$apiKey = "81c3566e60ef42e6afa1c2719e7843fd";
$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
$productDetails = getRezdyProducts($apiKey, $offset);

echo json_encode($productDetails);
