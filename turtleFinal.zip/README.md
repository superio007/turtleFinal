# WDM-Co_07-07-23
Welcome to our comprehensive tutorial on designing a responsive hotel booking website using HTML and CSS.
