<input name="merchantId" type="text" value="<?php echo $merchantId?>" hidden/>
<input name="amount" type="text" value="<?php echo $Amount ;?>" hidden/>
<input name="orderRef" type="text" value="<?php echo $orderRef ;?>" hidden/>
<input name="currCode" type="text" value="<?php echo $currCode; ?>"hidden />
<input name="successUrl" type="text" value="<?php echo $successUrl?>" hidden/>
<input name="failUrl" type="text" value="<?php echo $failUrl?>" hidden/>
<input name="cancelUrl" type="text" value="<?php echo $cancelUrl?>" hidden/>
<input name="payType" type="text" value="<?php echo $paymentType?>" hidden/>
<input name="lang" type="text" value="<?php echo $lang?>" hidden/>
<input name="mpsMode" type="text" value="<?php echo $mpsMode?>" hidden/>
<input name="payMethod" type="text" value="<?php echo $payMethod?>" hidden/>
<input name="secureHash" type="text" value="<?php echo $secureHash?>" hidden/>
<input name="remark" type="text" value="<?php echo $remark?>" hidden/>
<input name="redirect" type="text" value="<?php echo $redirect?>" hidden/>
<input name="oriCountry" type="text" value="<?php echo $oriCountry?>" hidden/>
<input name="destCountry" type="text" value="<?php echo $destCountry?>" hidden/>